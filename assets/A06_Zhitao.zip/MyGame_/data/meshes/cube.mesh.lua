return
{
	Vertices=
	{
	--------Index----Position----------------------Color---------------------Texture-----------
		{
			Index=0, Position={0.5,0.5,0.5},
		},
		{
			Index=1, Position={0.5,-0.5,0.5},
		},
		{
			Index=2, Position={-0.5,-0.5,0.5},
		},
		{
			Index=3, Position={-0.5,0.5,0.5},
		},
		{
			Index=4, Position={0.5,0.5,-0.5},
		},
		{
			Index=5, Position={0.5,-0.5,-0.5},
		},
		{
			Index=6, Position={-0.5,-0.5,-0.5},
		},
		{
			Index=7, Position={-0.5,0.5,-0.5},
		},
	};

	Indices=
	{
		0, 3, 1,
		1, 3, 2,
		7, 4, 5,
		7, 5, 6,
		4, 7, 3,
		4, 3, 0,
		6, 5, 1,
		6, 1, 2,
		4, 0, 1,
		4, 1, 5,
		3, 7, 6,
		3, 6, 2,
	};
}