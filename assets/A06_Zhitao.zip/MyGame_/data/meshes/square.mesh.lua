return
{
	Vertices=
	{
	--------Index----Position----------------------Color---------------------Texture-----------
		{
			Index=0, Position={0.5,0.5,0.0},
		},
		{
			Index=1, Position={0.5,-0.5,0.0},
		},
		{
			Index=2, Position={-0.5,-0.5,0.0},
		},
		{
			Index=3, Position={-0.5,0.5,0.0},
		},
	};

	Indices=
	{
		0, 3, 1,
		1, 3, 2,
	};
}