return
{
	Vertices=
	{
	--Index-Position-----------------Color---------------------Texture-----------
		{--0
			Position={0.5,0.5,0.0},
		},
		{--1
			Position={0.5,-0.5,0.0},
		},
		{--2
			Position={-0.5,-0.5,0.0},
		},
		{--3
			Position={-0.5,0.5,0.0},
		},
	};

	Indices=
	{
		--0
			0, 3, 1,
		--1
			1, 3, 2,
	};
}