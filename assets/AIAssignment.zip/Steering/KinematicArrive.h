#pragma once
#include<Steering/SteeringObject.h>

class KinematicArrive : public SteeringObject
{
public:
	KinematicArrive();
	KinematicArrive(Kinematic* i_character, Kinematic* i_target, float i_targetRadius, float i_slowRadius, float i_timeToTarget);
	~KinematicArrive();

	SteeringOutput GetSteering() override;

private:

	Kinematic* m_target;
	float m_targetRadius;
	float m_slowRadius;
	float m_timeToTarget;
};

