#include "DynamicWander.h"
#include <src/Tools.h>


DynamicWander::DynamicWander()
{
}

DynamicWander::DynamicWander(Kinematic * i_character, Kinematic * i_target, DynamicSeek * i_dynamicSeek, DynamicAlign * i_dynamicAlign, float i_targetDistance, float i_targetRadius):
	m_target(i_target),
	m_dynamicSeek(i_dynamicSeek),
	m_dynamicAlign(i_dynamicAlign),
	m_targetDistance(i_targetDistance),
	m_targetRadius(i_targetRadius)
{
	m_character = i_character;
}


DynamicWander::~DynamicWander()
{
	m_dynamicSeek = nullptr;
	m_dynamicAlign = nullptr;
}

SteeringOutput DynamicWander::GetSteering()
{
	SteeringOutput output;
	output.type = DYNAMIC;

	auto direction = m_character->GetDirection();
	auto targetCenter = m_character->GetPosition() + direction * m_targetDistance;
	auto rotation = RandomBinomial();
	auto newOri = m_character->GetOrientation() + rotation;
	auto newDirection = ofVec2f(glm::cos(newOri), glm::sin(newOri));
	auto targetPosition = targetCenter + newDirection * m_targetRadius;

	m_target->SetPosition(targetPosition);
	m_target->SetOrientation(newOri);

	auto linearOutput = m_dynamicSeek->GetSteering();
	auto angularOutput = m_dynamicAlign->GetSteering();

	output.acceleration = linearOutput.acceleration * 2.0f;
	output.angAcceleration = angularOutput.angAcceleration * 2.0f;

	return output;
}
