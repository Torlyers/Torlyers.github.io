#pragma once
#include <Steering/SteeringOutput.hpp>
#include <Steering/DynamicSeek.h>
#include <Steering/DynamicArrive.h>
#include <Steering/DynamicAlign.h>
#include <Steering/KinematicWander.h>
#include <Steering/KinematicArrive.h>
#include <Steering/DynamicWander.h>
#include <Steering/DynamicVelocityMatch.h>
#include <Steering/DynamicSeperation.h>
#include <Steering/DynamicFlocking.h>

enum SteeringType
{
	DYNAMIC_SEEK,
	KINEMATIC_ARRIVE,
	DYNAMIC_ARRIVE,	
	DYNAMIC_ALIGN,
	KINEMATIC_WANDER,
	DYNAMIC_WANDER,
	DYNAMIC_FLOCKING,
};

class SteeringComponent
{
public:
	SteeringComponent();
	SteeringComponent(Kinematic* i_character);
	~SteeringComponent();

	void SetTarget(const Kinematic& i_target);
	void SetTargetPosition(ofVec2f i_pos);
	void SetTargetPosition(float x, float y);
	void SetTargetsVec(std::vector<Kinematic*>* i_targetsVec);

	SteeringOutput GetSteering(SteeringType type);

private:

	float m_maxSpeed;
	float m_maxAcceleration;
	float m_maxAngSpeed;
	float m_maxAngAccel;
	float m_slowRadius;
	float m_targetRadius;
	float m_slowAngThres;
	float m_targetAngThres;
	float m_timeToTarget;
	float m_wanderTargetDistance;
	float m_wanderTargetRadius;
	float m_distThres;
	float m_forceFactor;

	Kinematic* m_character;
	Kinematic m_target;
	std::vector<Kinematic*>* m_targetsVec;//for flocking

	//Steering objects
	DynamicSeek* m_dynamicSeek;
	DynamicArrive* m_dynamicArrive;
	DynamicAlign* m_dynamicAlign;
	KinematicWander* m_kinematicWander;
	KinematicArrive* m_kinematicArrive;
	DynamicWander* m_dynamicWander;
	DynamicVelocityMatch* m_dynamicVelocityMatch;
	DynamicSeperation* m_dynamicSeperation;
	DynamicFlocking* m_dynamicFlocking;	

};

