#pragma once
#include <ofVec2f.h>
#include "SteeringOutput.hpp"
#include <Kinematic/Kinematic.h>

class SteeringObject
{
public:

	virtual SteeringOutput GetSteering() = 0;
	SteeringObject();
	virtual ~SteeringObject();

protected:
	Kinematic* m_character;
	class SteeringComponent* m_steeringComponent;
};

