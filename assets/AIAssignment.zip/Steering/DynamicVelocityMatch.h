#pragma once
#include<Steering/SteeringObject.h>

class DynamicVelocityMatch : public SteeringObject
{
public:
	DynamicVelocityMatch();
	DynamicVelocityMatch(Kinematic* i_character, Kinematic* i_target, float timeToTarget);
	~DynamicVelocityMatch();

	SteeringOutput GetSteering() override;

private:
	Kinematic* m_target;
	float m_timeToTarget;
};

