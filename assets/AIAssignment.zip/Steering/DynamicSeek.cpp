#include "DynamicSeek.h"



DynamicSeek::DynamicSeek()
{
}

DynamicSeek::DynamicSeek(Kinematic* i_character, Kinematic* i_target, float i_maxAccel):
	m_maxAcceleration(i_maxAccel)
{
	m_target = i_target;
	m_character = i_character;
}


DynamicSeek::~DynamicSeek()
{
}

void DynamicSeek::SetTargetPosition(ofVec2f i_pos)
{
	m_target->SetPosition(i_pos);
}

void DynamicSeek::SetMaxAcceleration(float i_accel)
{
	m_maxAcceleration = i_accel;
}

SteeringOutput DynamicSeek::GetSteering()
{
	SteeringOutput output;
	output.type = DYNAMIC;
	
	auto difference = m_target->GetPosition() - m_character->GetPosition();
	auto direction = difference.getNormalized();
	auto acceleration = direction * m_maxAcceleration;
	output.acceleration = acceleration;

	return output;
}
