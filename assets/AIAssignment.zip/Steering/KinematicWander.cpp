#include "KinematicWander.h"
#include <src/Tools.h>



KinematicWander::KinematicWander()
{
}

KinematicWander::KinematicWander(Kinematic * i_character, float i_maxSpeed, float i_maxAngSpeed):
	m_maxSpeed(i_maxSpeed),
	m_maxAngSpeed(i_maxAngSpeed)
{
	m_character = i_character;
}


KinematicWander::~KinematicWander()
{
}

SteeringOutput KinematicWander::GetSteering()
{
	SteeringOutput output;
	output.type = KINEMATIC;
	output.velocity = m_character->GetDirection() * m_maxSpeed;
	output.angVelocity = m_maxAngSpeed * RandomBinomial();
	return output;
}
