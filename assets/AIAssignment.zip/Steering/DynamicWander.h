#pragma once
#include<Steering/SteeringObject.h>
#include<Steering/DynamicSeek.h>
#include<Steering/DynamicAlign.h>

class DynamicWander : public SteeringObject
{
public:
	DynamicWander();
	DynamicWander(Kinematic* i_character, Kinematic* i_target, DynamicSeek* i_dynamicSeek, DynamicAlign* i_dynamicAlign, float i_targetDistance, float i_targetRadius);
	~DynamicWander();

	SteeringOutput GetSteering() override;

private:
	Kinematic* m_target;
	DynamicSeek* m_dynamicSeek;
	DynamicAlign* m_dynamicAlign;
	float m_targetDistance;
	float m_targetRadius;
};

