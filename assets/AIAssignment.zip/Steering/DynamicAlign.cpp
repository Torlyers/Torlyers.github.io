#include "DynamicAlign.h"
#include <src/Tools.h>


DynamicAlign::DynamicAlign()
{
}

DynamicAlign::DynamicAlign(Kinematic * i_character, Kinematic * i_target, float i_maxAngVelo, float i_maxAngAccel, float i_slowAngThres, float i_targetAngThres, float i_timeToTarget):
	m_target(i_target),
	m_maxAngVelo(i_maxAngAccel),
	m_maxAngAccel(i_maxAngAccel),
	m_slowAngThres(i_slowAngThres),
	m_targetAngThres(i_targetAngThres),
	m_timeToTarget(i_timeToTarget)
{
	m_character = i_character;
}


DynamicAlign::~DynamicAlign()
{
}

SteeringOutput DynamicAlign::GetSteering()
{
	SteeringOutput output;
	output.type = DYNAMIC;
	
	auto rotation = m_target->GetOrientation() - m_character->GetOrientation();
	rotation = MapToRange(rotation);

	if (abs(rotation) < m_targetAngThres)
	{
		m_character->SetAngVelocity(0);
		return output;
	}

	float angVelocity;
	if (abs(rotation) > m_slowAngThres)
	{
		angVelocity = rotation / abs(rotation) * m_maxAngVelo;
	}
	else
	{
		float scaleFactor = abs(rotation) / m_slowAngThres;
		angVelocity = rotation / abs(rotation) * m_maxAngVelo * scaleFactor;
	}

	auto dv = angVelocity - m_character->GetAngVelocity();
	auto a = dv / m_timeToTarget;

	output.angAcceleration = a;
	return output;
}
