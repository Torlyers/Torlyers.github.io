#pragma once
#include <Steering/SteeringObject.h>
#include <Steering/DynamicSeperation.h>
#include <Steering/DynamicVelocityMatch.h>
#include <Steering/DynamicSeek.h>
#include <Steering/DynamicAlign.h>

class DynamicFlocking : public SteeringObject
{
public:
	DynamicFlocking();
	DynamicFlocking(Kinematic* i_character, Kinematic* i_target, std::vector<Kinematic*>* i_targetsVec, 
		DynamicSeek* i_dynamicSeek, DynamicAlign* i_dynamicAlign, DynamicVelocityMatch* i_dynamicVelocityMatch,
		DynamicSeperation* i_dynamicSeperation);
	~DynamicFlocking();

	SteeringOutput GetSteering() override;

	void SetTargetVec(std::vector<Kinematic*>* i_targetsVec) { m_targetsVec = i_targetsVec; }

private:
	std::vector<Kinematic*>* m_targetsVec;
	Kinematic* m_target;
	DynamicSeek* m_dynamicSeek;
	DynamicAlign* m_dynamicAlign;
	DynamicVelocityMatch* m_dynamicVelocityMatch;
	DynamicSeperation* m_dynamicSeperation;
};

