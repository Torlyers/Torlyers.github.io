#include "DynamicArrive.h"



DynamicArrive::DynamicArrive()
{
}

DynamicArrive::DynamicArrive(Kinematic * i_character, Kinematic * i_target, float i_maxAcceleration, float i_maxSpeed, float i_targetRadius, float i_slowRadius, float i_timeToTarget):
	m_target(i_target),
	m_maxAcceleration(i_maxAcceleration),
	m_maxSpeed(i_maxSpeed),
	m_targetRadius(i_targetRadius),
	m_slowRadius(i_slowRadius),
	m_timeToTarget(i_timeToTarget)
{
	m_character = i_character;
}


DynamicArrive::~DynamicArrive()
{
}

SteeringOutput DynamicArrive::GetSteering()
{
	SteeringOutput output;
	output.type = DYNAMIC;

	auto difference = m_target->GetPosition() - m_character->GetPosition();
	auto distance = difference.length();

	if (distance < m_targetRadius)
	{
		m_character->Stop();
		return output;
	}

	float speed;
	if (distance > m_slowRadius)
	{
		//if character is out of slow radius, use seek behavior
		output.type = NONE;
		return output;
	}
	else
	{
		float scalingFactor = distance / m_slowRadius;
		speed = scalingFactor * m_maxSpeed;
	}

	auto velocity = difference.getNormalized() * speed;
	auto dv = velocity - m_character->GetVelocity();
	auto a = dv / m_timeToTarget;
	output.acceleration = a;

	return output;
}
