#include "SteeringObject.h"



SteeringObject::SteeringObject()
{
}


SteeringObject::~SteeringObject()
{
}
