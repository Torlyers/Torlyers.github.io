#include "DynamicVelocityMatch.h"



DynamicVelocityMatch::DynamicVelocityMatch()
{
}

DynamicVelocityMatch::DynamicVelocityMatch(Kinematic * i_character, Kinematic * i_target, float i_timeToTarget):
	m_target(i_target),
	m_timeToTarget(i_timeToTarget)
{
	m_character = i_character;
}


DynamicVelocityMatch::~DynamicVelocityMatch()
{
}

SteeringOutput DynamicVelocityMatch::GetSteering()
{
	SteeringOutput output;
	output.type = DYNAMIC;

	auto deltaVelocity = m_target->GetVelocity() - m_character->GetVelocity();
	output.acceleration = deltaVelocity / m_timeToTarget;

	return output;
}
