#pragma once
#include<Steering/SteeringObject.h>

class DynamicSeperation : public SteeringObject
{
public:
	DynamicSeperation();
	DynamicSeperation(Kinematic* i_character, std::vector<Kinematic*>* i_targetsVec, float i_distThres, float i_forceFactor, float i_maxAccel);
	~DynamicSeperation();

	SteeringOutput GetSteering() override;

	void SetTargetVec(std::vector<Kinematic*>* i_targetsVec) { m_targetsVec = i_targetsVec; }

private:
	std::vector<Kinematic*>* m_targetsVec;
	float m_distThres;
	float m_forceFactor;
	float m_maxAccel;
};

