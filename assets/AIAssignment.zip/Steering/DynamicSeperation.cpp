#include "DynamicSeperation.h"

DynamicSeperation::DynamicSeperation()
{
}

DynamicSeperation::DynamicSeperation(Kinematic * i_character, std::vector<Kinematic*>* i_targetsVec, float i_distThres, float i_forceFactor, float i_maxAccel):
	m_targetsVec(i_targetsVec),
	m_distThres(i_distThres),
	m_forceFactor(i_forceFactor),
	m_maxAccel(i_maxAccel)
{
	m_character = i_character;
}


DynamicSeperation::~DynamicSeperation()
{
}

SteeringOutput DynamicSeperation::GetSteering()
{
	SteeringOutput output;
	output.type = DYNAMIC;

	for (int i = 0; i < m_targetsVec->size(); ++i)
	{
		auto target = (*m_targetsVec)[i];
		auto difference = target->GetPosition() - m_character->GetPosition();
		auto distance = difference.length();
		float strength = 0;
		if (distance >= m_distThres || distance <= 0.0001f)
		{
			continue;
		}
		else
		{
			strength = m_forceFactor / glm::pow(distance, 2);
			output.acceleration += strength * (-difference.normalize());//force direction is on the opposite way
		}
	}

	return output;
}
