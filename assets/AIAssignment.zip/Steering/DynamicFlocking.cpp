#include "DynamicFlocking.h"



DynamicFlocking::DynamicFlocking()
{
}

DynamicFlocking::DynamicFlocking(Kinematic * i_character, Kinematic * i_target, std::vector<Kinematic*>* i_targetsVec, DynamicSeek * i_dynamicSeek, DynamicAlign * i_dynamicAlign, DynamicVelocityMatch * i_dynamicVelocityMatch, DynamicSeperation * i_dynamicSeperation):
	m_target(i_target),
	m_targetsVec(i_targetsVec),
	m_dynamicSeek(i_dynamicSeek),
	m_dynamicAlign(i_dynamicAlign),
	m_dynamicVelocityMatch(i_dynamicVelocityMatch),
	m_dynamicSeperation(i_dynamicSeperation)
{
	m_character = i_character;
}


DynamicFlocking::~DynamicFlocking()
{
	m_targetsVec = nullptr;
	m_dynamicAlign = nullptr;
	m_dynamicSeek = nullptr;
	m_dynamicSeperation = nullptr;
	m_dynamicVelocityMatch = nullptr;
}

SteeringOutput DynamicFlocking::GetSteering()
{
	SteeringOutput output;
	output.type = DYNAMIC;

	auto seekoutput = m_dynamicSeek->GetSteering();
	auto alignoutput = m_dynamicAlign->GetSteering();
	auto velocityMatchOutput = m_dynamicVelocityMatch->GetSteering();
	auto seperationOutput = m_dynamicSeperation->GetSteering();

	output.acceleration = seekoutput.acceleration * 0.1f +
						velocityMatchOutput.acceleration * 0.1f +
						seperationOutput.acceleration * 0.8f;
	output.angAcceleration = alignoutput.angAcceleration;

	return output;
}
