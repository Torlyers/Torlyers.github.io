#pragma once
#include <Steering/SteeringObject.h>

class DynamicSeek : public SteeringObject
{
public:

	DynamicSeek();
	DynamicSeek(Kinematic* i_character, Kinematic* i_target, float i_maxAccel);
	~DynamicSeek();

	void SetTargetPosition(ofVec2f i_pos);
	void SetMaxAcceleration(float i_accel);
	SteeringOutput GetSteering() override;

private:
	Kinematic* m_target;
	float m_maxAcceleration;
};

