#pragma once
#include<Steering/SteeringObject.h>

class DynamicArrive : public SteeringObject
{
public:
	DynamicArrive();
	DynamicArrive(Kinematic* i_character, Kinematic* i_target, float i_maxAcceleration, float i_maxSpeed, float i_targetRadius,
		float i_slowRadius, float i_timeToTarget);
	~DynamicArrive();

	SteeringOutput GetSteering() override;

private:

	Kinematic* m_target;
	float m_maxAcceleration;
	float m_maxSpeed;
	float m_targetRadius;
	float m_slowRadius;
	float m_timeToTarget;
};

