#include "SteeringComponent.h"

SteeringComponent::SteeringComponent()
{
}	

SteeringComponent::SteeringComponent(Kinematic * i_character):
	m_character(i_character)
{

	m_maxAcceleration = 200.0f;
	m_maxSpeed = i_character->GetMaxSpeed();
	m_targetRadius = 10.0f;
	m_slowRadius = 100.0f;
	m_timeToTarget = 0.3f;
	m_maxAngSpeed = i_character->GetMaxAngSpeed();
	m_maxAngAccel = 10.0f;
	m_slowAngThres = 0.5f;
	m_targetAngThres = 0.05f;
	m_wanderTargetDistance = 30.0f;
	m_wanderTargetRadius = 30.0f;
	m_distThres = 100.0f;
	m_forceFactor = 10000.0f;

	m_dynamicSeek = new DynamicSeek(i_character, &m_target, m_maxAcceleration);
	m_dynamicArrive = new DynamicArrive(i_character, &m_target, m_maxAcceleration, m_maxSpeed, m_targetRadius, m_slowRadius, m_timeToTarget);
	m_dynamicAlign = new DynamicAlign(i_character, &m_target, m_maxAngSpeed, m_maxAngAccel, m_slowAngThres, m_targetAngThres, m_timeToTarget);
	m_kinematicWander = new KinematicWander(i_character, m_maxSpeed, m_maxAngSpeed);
	m_kinematicArrive = new KinematicArrive(i_character, &m_target, m_targetRadius, m_targetRadius, m_timeToTarget);
	//must be initialized after dynamic seek and dynamic align
	m_dynamicWander = new DynamicWander(i_character, &m_target, m_dynamicSeek, m_dynamicAlign, m_wanderTargetDistance, m_wanderTargetRadius);
	m_dynamicVelocityMatch = new DynamicVelocityMatch(i_character, &m_target, m_timeToTarget);
	m_dynamicSeperation = new DynamicSeperation(i_character, m_targetsVec, m_distThres, m_forceFactor, m_maxAcceleration);

	//must be initialized after seek, align, velocity match, and seperation
	m_dynamicFlocking = new DynamicFlocking(i_character, &m_target, m_targetsVec, m_dynamicSeek, m_dynamicAlign,
											m_dynamicVelocityMatch, m_dynamicSeperation);
}

SteeringComponent::~SteeringComponent()
{
	delete m_dynamicFlocking;
	delete m_dynamicWander;
	delete m_dynamicSeek;
	delete m_dynamicArrive;
	delete m_dynamicAlign;
	delete m_kinematicWander;
	delete m_kinematicArrive;
	delete m_dynamicVelocityMatch;	
	delete m_dynamicSeperation;
}

void SteeringComponent::SetTarget(const Kinematic & i_target)
{
	m_target = i_target;
}

void SteeringComponent::SetTargetPosition(ofVec2f i_pos)
{
	m_target.SetPosition(i_pos);
}

void SteeringComponent::SetTargetPosition(float x, float y)
{
	m_target.SetPosition(x, y);
	auto difference = m_target.GetPosition() - m_character->GetPosition();
	auto direction = difference.getNormalized();
	float orientation = std::atan2f(direction.y, direction.x);
	m_target.SetOrientation(orientation);
}

void SteeringComponent::SetTargetsVec(std::vector<Kinematic*>* i_targetsVec)
{
	m_targetsVec = i_targetsVec;
	m_dynamicSeperation->SetTargetVec(i_targetsVec);
	m_dynamicFlocking->SetTargetVec(i_targetsVec);
}

SteeringOutput SteeringComponent::GetSteering(SteeringType type)
{
	SteeringOutput output;
	switch (type)
	{
	case DYNAMIC_SEEK:
		output = m_dynamicSeek->GetSteering();
		break;
	case KINEMATIC_ARRIVE:
		output = m_kinematicArrive->GetSteering();
		break;
	case DYNAMIC_ARRIVE:
		output = m_dynamicArrive->GetSteering();
		break;
	case DYNAMIC_ALIGN:
		output = m_dynamicAlign->GetSteering();
		break;
	case KINEMATIC_WANDER:
		output = m_kinematicWander->GetSteering();
		break;
	case DYNAMIC_WANDER:
		output = m_dynamicWander->GetSteering();
		break;
	case DYNAMIC_FLOCKING:
		output = m_dynamicFlocking->GetSteering();
		break;
	default:
		break;
	}

	return output;
}
