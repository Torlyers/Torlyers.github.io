#include "KinematicArrive.h"



KinematicArrive::KinematicArrive()
{
}

KinematicArrive::KinematicArrive(Kinematic * i_character, Kinematic * i_target, float i_targetRadius, float i_slowRadius, float i_timeToTarget):
	m_target(i_target),
	m_targetRadius(i_targetRadius),
	m_slowRadius(i_slowRadius),
	m_timeToTarget(i_slowRadius)
{
	m_character = i_character;
}


KinematicArrive::~KinematicArrive()
{
}

SteeringOutput KinematicArrive::GetSteering()
{
	SteeringOutput output;
	output.type = KINEMATIC;

	auto difference = m_target->GetPosition() - m_character->GetPosition();
	auto distance = difference.length();

	if (distance < m_targetRadius)
	{
		m_character->Stop();
		return output;
	}

	float speed = m_character->GetCurrentSpeed();
	auto velocity = difference.getNormalized() * speed;
	if (distance > m_slowRadius)
	{
		output.type = NONE;
		return output;
	}
	else
	{
		velocity /= m_timeToTarget;
	}

	output.velocity = velocity;
	return output;
}
