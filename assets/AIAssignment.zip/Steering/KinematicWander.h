#pragma once
#include<Steering/SteeringObject.h>

class KinematicWander : public SteeringObject
{
public:
	KinematicWander();
	KinematicWander(Kinematic* i_character, float i_maxSpeed, float i_maxAngSpeed);
	~KinematicWander();
	SteeringOutput GetSteering() override;

private:

	float m_maxSpeed;
	float m_maxAngSpeed;
};

