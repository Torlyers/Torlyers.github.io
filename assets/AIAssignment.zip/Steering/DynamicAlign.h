#pragma once
#include <Steering/SteeringObject.h>

class DynamicAlign : public SteeringObject
{
public:
	DynamicAlign();
	DynamicAlign(Kinematic* i_character, Kinematic* i_target, float i_maxAngVelo, float i_maxAngAccel, float i_slowAngThres, float i_targetAngThres, float i_timeToTarget);
	~DynamicAlign();

	virtual SteeringOutput GetSteering() override;

private:

	Kinematic* m_target;
	float m_maxAngVelo;
	float m_maxAngAccel;
	float m_slowAngThres;
	float m_targetAngThres;
	float m_timeToTarget;
};

