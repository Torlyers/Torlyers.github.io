#pragma once
#include <ofVec2f.h>


enum SteeringOutputType
{
	NONE,
	KINEMATIC,
	DYNAMIC,
};

struct SteeringOutput
{
	SteeringOutputType type = KINEMATIC;
	ofVec2f velocity = {0, 0};
	float angVelocity = 0;
	ofVec2f acceleration = {0, 0};
	float angAcceleration = 0;
};
