#include "ofApp.h"
#include "Boid.h"
#include <Steering/SteeringOutput.hpp>
#include <Steering/SteeringComponent.h>
#include <glm/glm.hpp>

//--------------------------------------------------------------
void ofApp::setup()
{
	//Global Settings
	ofBackground(150, 200, 255);
	m_gameMode = FLOCKING;
	m_motionMode = DYNAMIC;
	m_lastFrameTime = 0;

	leftBorder = 20.0f;
	rightBorder = ofGetViewportWidth() - 20.0f;
	upBorder = 20.0f;
	bottomBorder = ofGetViewportHeight() - 20.0f;
	widthCenter = ofGetViewportWidth() / 2.0f;
	heightCenter = ofGetViewportHeight() / 2.0f;

	//Init GameObjects
	boid = new Boid();
	boid->GetKinematic().SetPosition(widthCenter, heightCenter);
	boid->GetSteeringComponent()->SetTarget(boid->GetKinematic());
	allboids.push_back(boid);
	kinematics.push_back(&(boid->GetKinematic()));
	boid->SetIsLeader(true);
	boid->GetSteeringComponent()->SetTargetsVec(&kinematics);

	followerNum = 4;
	for (int i = 0; i < followerNum; ++i)
	{
		Boid* follower = new Boid();
		glm::linearRand(-50.0f, 50.0f);
		follower->GetKinematic().SetPosition(widthCenter + glm::linearRand(-50.0f, 50.0f), heightCenter + glm::linearRand(-50.0f, 50.0f));
		follower->GetSteeringComponent()->SetTarget(boid->GetKinematic());
		allboids.push_back(follower);
		kinematics.push_back(&(follower->GetKinematic()));
		follower->GetSteeringComponent()->SetTargetsVec(&kinematics);
	}
}

//--------------------------------------------------------------
void ofApp::update()
{
	auto currentTime = ofGetElapsedTimef();
	auto deltaTime = currentTime - m_lastFrameTime;
	m_lastFrameTime = currentTime;

	SteeringOutput output;
	switch (m_gameMode)
	{
	//basic-motion
	case ofApp::BASIC:	
		output.velocity = boid->GetKinematic().GetDirection() * 50.0f;
		boid->Update(output, deltaTime);
		break;
	//seek steering
	case ofApp::SEEK:

		//Update linear first. If boid is out of slow radius, use seek steering
		if (m_motionMode == KINEMATIC)
		{
			output = boid->GetSteeringComponent()->GetSteering(KINEMATIC_ARRIVE);
			if (output.type == NONE)
			{
				output = boid->GetSteeringComponent()->GetSteering(DYNAMIC_SEEK);
			}
		}
		else
		{
			output = boid->GetSteeringComponent()->GetSteering(DYNAMIC_ARRIVE);
			if (output.type == NONE)
			{
				output = boid->GetSteeringComponent()->GetSteering(DYNAMIC_SEEK);
			}
		}
		
		boid->Update(output, deltaTime);
		
		//update angular
		output = boid->GetSteeringComponent()->GetSteering(DYNAMIC_ALIGN);
		boid->Update(output, deltaTime);	

		break;
	//wander steering
	case ofApp::WANDER:
		if (m_motionMode == KINEMATIC)
		{
			output = boid->GetSteeringComponent()->GetSteering(KINEMATIC_WANDER);
		}
		else
		{
			output = boid->GetSteeringComponent()->GetSteering(DYNAMIC_WANDER);
		}
		boid->Update(output, deltaTime);
		break;
	//flocking
	case ofApp::FLOCKING:

		//The leader is wandering
		if (m_motionMode == KINEMATIC)
		{
			output = boid->GetSteeringComponent()->GetSteering(KINEMATIC_WANDER);
		}
		else
		{
			output = boid->GetSteeringComponent()->GetSteering(DYNAMIC_WANDER);
		}
		boid->Update(output, deltaTime);

		//all followers call flocking steering
		for (auto oneboid : allboids)
		{
			if(oneboid->GetIsLeader())
				continue;
			oneboid->GetSteeringComponent()->SetTarget(boid->GetKinematic());
			output = oneboid->GetSteeringComponent()->GetSteering(DYNAMIC_FLOCKING);
			oneboid->Update(output, deltaTime);
		}
		break;
	default:
		break;
	}	
	HandleBorderCollision(boid, deltaTime);
}

//--------------------------------------------------------------
void ofApp::draw()
{
	boid->Draw();

	if (m_gameMode == FLOCKING)
	{
		for (auto follower : allboids)
		{
			follower->Draw();
		}
	}
}

void ofApp::exit()
{
	for (auto oneBoid : allboids)
	{
		delete oneBoid;
	}
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key)
{
	switch (key)
	{
	case '1':
		SwitchGameMode(BASIC);
		break;
	case '2':
		SwitchGameMode(SEEK);
		break;
	case '3':
		SwitchGameMode(WANDER);
		break;
	case '4':
		SwitchGameMode(FLOCKING);
		break;
	case '5':
		SwitchMotionMode(KINEMATIC);
		break;
	case '6':
		SwitchMotionMode(DYNAMIC);
		break;
	case '7':
		if (m_gameMode == FLOCKING)
		{
			RandomSwitchLeader();
		}
		break;
	default:
		break;
	}

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key)
{

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y )
{

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button)
{

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button)
{
	
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button)
{
	if (m_gameMode == SEEK)
	{
		boid->GetSteeringComponent()->SetTargetPosition(x, y);
	}
}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y)
{

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y)
{

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h)
{

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg)
{

}

void ofApp::SwitchGameMode(GameMode mode)
{
	for (auto kinematic : kinematics)
	{
		kinematic->Reset();
	}
	if (mode == BASIC)
	{
		boid->GetKinematic().SetPosition(leftBorder, bottomBorder);
	}
	else
	{
		boid->GetKinematic().SetPosition(widthCenter, heightCenter);
	}
	for (int i = 0; i < followerNum; ++i)
	{
		auto follower = allboids[i];
		follower->GetKinematic().SetPosition(widthCenter + glm::linearRand(-50.0f, 50.0f), heightCenter + glm::linearRand(-50.0f, 50.0f));
	}	
	
	m_gameMode = mode;
}

void ofApp::SwitchMotionMode(MotionMode mode)
{
	m_motionMode = mode;
	SwitchGameMode(m_gameMode);
}

void ofApp::HandleBorderCollision(Boid * boid, float deltaTime)
{
	if (boid->GetKinematic().GetPosition().x < leftBorder ||
		boid->GetKinematic().GetPosition().x > rightBorder ||
		boid->GetKinematic().GetPosition().y < upBorder ||
		boid->GetKinematic().GetPosition().y > bottomBorder)
	{
		boid->GetKinematic().Translate(boid->GetKinematic().GetVelocity() * deltaTime * -2.0f);
		boid->GetKinematic().RotateRad(glm::radians(-90.0f));
	}
}

void ofApp::HandleWanderBorderCollision(Boid * boid)
{
	
}

void ofApp::RandomSwitchLeader()
{
	int randomIndex = glm::linearRand(0, followerNum);
	while (allboids[randomIndex] == boid)
	{
		randomIndex = glm::linearRand(0, 10);
	}
	boid->SetIsLeader(false);
	allboids[randomIndex]->SetIsLeader(true);
	boid = allboids[randomIndex];
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo)
{ 

}
