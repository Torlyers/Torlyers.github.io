#include "Boid.h"
#include "ofApp.h"

Boid::Boid():
	m_circleRadius(10.0f),
	m_triangleHeight(8.0f),
	m_breadcrumbInterval(0.5f),
	m_breadcrumbMaxNum(100),
	m_breadcrumbRadius(2.0f)
{
	m_kinematic.SetPosition(20.0f, 20.0f);
	m_breadcrumbTimer = m_breadcrumbInterval;
	m_steeringComponent = new SteeringComponent(&m_kinematic);
	m_isLeader = false;
}


Boid::~Boid()
{
	if (m_steeringComponent != nullptr)
	{
		delete m_steeringComponent;
	}
}

void Boid::Update(SteeringOutput output, float deltaTime)
{
	m_kinematic.Update(output, deltaTime);
}

void Boid::Draw()
{
	if (m_isLeader)
	{
		ofSetColor(255, 180, 160);
	}
	else
	{
		ofSetColor(255, 255, 255);
	}

	ofDrawCircle(m_kinematic.GetPosition().x, m_kinematic.GetPosition().y, m_circleRadius);
	auto ax = m_circleRadius;
	auto ay = m_triangleHeight;
	auto bx = m_circleRadius;
	auto by = -m_triangleHeight;
	auto cx = m_circleRadius + m_triangleHeight;
	auto cy = 0.0f;
	
	ofPushMatrix();
	ofTranslate(m_kinematic.GetPosition().x, m_kinematic.GetPosition().y);//change rotation origin to the center of circle 
	ofRotateRad(m_kinematic.GetOrientation());
	ofDrawTriangle(ax, ay, bx, by, cx, cy);
	ofPopMatrix();

	m_breadcrumbTimer -= ofGetLastFrameTime();
	if (m_breadcrumbTimer <= 0)
	{
		m_breadcrumbs.push_back(m_kinematic.GetPosition());
		if (m_breadcrumbs.size() > m_breadcrumbMaxNum)
		{
			m_breadcrumbs.pop_front();
		}
		m_breadcrumbTimer = m_breadcrumbInterval;
	}

	for (auto position : m_breadcrumbs)
	{
		ofDrawCircle(position, m_breadcrumbRadius);
	}

}

bool Boid::GetIsLeader()
{
	return m_isLeader;
}

void Boid::SetIsLeader(bool i_isLeader)
{
	m_isLeader = i_isLeader;
}

SteeringComponent * Boid::GetSteeringComponent()
{
	return m_steeringComponent;
}
