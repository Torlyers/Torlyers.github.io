#pragma once
#include <glm/gtc/random.hpp>

#define PI 3.14f

inline float RandomBinomial()
{
	return glm::linearRand(-1.0f, 1.0f) - glm::linearRand(-1.0f, 1.0f);
}

inline float MapToRange(float rotation)
{
	while (rotation > PI)
		rotation -= 2 * PI;
	while (rotation < -PI)
		rotation += 2 * PI;

	return rotation;
}
