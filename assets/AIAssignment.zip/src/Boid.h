#pragma once
#include <Kinematic/GameObject.h>
#include <Steering/SteeringComponent.h>
#include <deque>

class Boid: public GameObject
{
public:
	Boid();
	~Boid();

	virtual void Update(SteeringOutput output, float deltaTime) override;
	virtual void Draw() override;

	bool GetIsLeader();
	void SetIsLeader(bool i_isLeader);

	SteeringComponent* GetSteeringComponent();

private:

	float m_circleRadius;
	float m_triangleHeight;
	
	std::deque<ofVec2f> m_breadcrumbs;
	int m_breadcrumbMaxNum;
	float m_breadcrumbTimer;
	float m_breadcrumbInterval;
	float m_breadcrumbRadius;

	SteeringComponent* m_steeringComponent;

	bool m_isLeader;
};

