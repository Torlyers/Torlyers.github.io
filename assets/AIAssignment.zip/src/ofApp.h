#pragma once

#include "ofMain.h"
#include "Boid.h"

class ofApp : public ofBaseApp
{

public:

	void setup();
	void update();
	void draw();
	void exit();

	void keyPressed(int key);
	void keyReleased(int key);
	void mouseMoved(int x, int y );
	void mouseDragged(int x, int y, int button);
	void mousePressed(int x, int y, int button);
	void mouseReleased(int x, int y, int button);
	void mouseEntered(int x, int y);
	void mouseExited(int x, int y);
	void windowResized(int w, int h);
	void dragEvent(ofDragInfo dragInfo);
	void gotMessage(ofMessage msg);


public:
	enum GameMode
	{
		BASIC,
		SEEK,
		WANDER,
		FLOCKING,
	};
	enum MotionMode
	{
		KINEMATIC,
		DYNAMIC,
	};

	void SwitchGameMode(GameMode mode);
	void SwitchMotionMode(MotionMode mode);
	void HandleBorderCollision(Boid* boid, float deltaTime);
	void HandleWanderBorderCollision(Boid* boid);

	void RandomSwitchLeader();

private:

	//Global Variables
	GameMode m_gameMode;
	MotionMode m_motionMode;
	float m_lastFrameTime;

	float leftBorder;
	float rightBorder;
	float upBorder;
	float bottomBorder;
	float widthCenter;
	float heightCenter;
	
	//GameObjects
	Boid* boid;

	//flocking
	int followerNum;
	std::vector<Boid*> allboids;
	std::vector<Kinematic*> kinematics;
		
};
