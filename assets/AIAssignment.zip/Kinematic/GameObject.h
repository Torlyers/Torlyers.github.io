#pragma once
#include <Steering/SteeringObject.h>
#include <Kinematic/Kinematic.h>>
#include <Steering/SteeringOutput.hpp>

class GameObject
{
public:
	GameObject();
	~GameObject();

	virtual void Update(SteeringOutput output, float deltaTime) {}
	virtual void Draw() {}

	Kinematic& GetKinematic() { return m_kinematic; }

protected:

	SteeringObject* m_steeringObject;
	Kinematic m_kinematic;
};

