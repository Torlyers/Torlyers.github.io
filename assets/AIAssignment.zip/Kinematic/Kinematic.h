#pragma once
#include <ofVec2f.h>
#include <glm/glm.hpp>



class Kinematic
{
public:
	Kinematic();
	~Kinematic();

	ofVec2f GetPosition() { return m_position; }
	void SetPosition(float x, float y) {m_position.x = x; m_position.y = y;}
	void SetPosition(ofVec2f i_pos) { m_position = i_pos; }

	float GetOrientation() { return m_orientation; }
	void SetOrientation(float i_ori) { m_orientation = i_ori; }

	ofVec2f GetVelocity() { return m_velocity; }
	void SetVelocity(float vx, float vy) { m_velocity.x = vx, m_velocity.y = vy; }

	float GetAngVelocity() { return m_angVelocity; }
	void SetAngVelocity(float i_angVel) { m_angVelocity = i_angVel; }

	ofVec2f GetDirection() { return ofVec2f(glm::cos(m_orientation), glm::sin(m_orientation)).getNormalized(); }

	void Update(struct SteeringOutput steering, float deltaTime);

	void Translate(ofVec2f i_trans) { m_position += i_trans; }
	void RotateRad(float i_rotRad) { m_orientation += i_rotRad; }

	void Reset();
	void Stop();

	float GetMaxSpeed() { return m_maxSpeed; }
	float GetMaxAngSpeed() { return m_maxAngSpeed; }
	float GetCurrentSpeed() { return m_velocity.length(); }

private:

	ofVec2f m_position;
	float m_orientation;
	ofVec2f m_velocity;
	float m_angVelocity;

	float m_maxSpeed;
	float m_maxAngSpeed;

};