#include "Kinematic.h"
#include <Steering/SteeringOutput.hpp>

Kinematic::Kinematic():
	m_position(0, 0),
	m_orientation(0),
	m_velocity(0, 0),
	m_angVelocity(0)
{
	m_maxSpeed = 50.0f;
	m_maxAngSpeed = 2.0f;
}


Kinematic::~Kinematic()
{
}

void Kinematic::Update(SteeringOutput steering, float deltaTime)
{
	switch (steering.type)
	{
	case KINEMATIC:
		m_velocity = steering.velocity;
		m_angVelocity = steering.angVelocity;
		break;
	case DYNAMIC:
		m_velocity += steering.acceleration * deltaTime;
		m_angVelocity += steering.angAcceleration * deltaTime;
		break;
	default:
		break;
	}

	if (m_velocity.length() > m_maxSpeed)
	{
		m_velocity = m_velocity.getNormalized() * m_maxSpeed;
	}

	if (abs(m_angVelocity) > m_maxAngSpeed)
	{
		m_angVelocity = m_angVelocity / abs(m_angVelocity) * m_maxAngSpeed;
	}

	m_position += m_velocity * deltaTime;
	m_orientation += m_angVelocity * deltaTime;

}

void Kinematic::Reset()
{
	m_position = { 0, 0 };
	m_orientation = 0;
	Stop();
}

void Kinematic::Stop()
{
	m_velocity = { 0, 0 };
	m_angVelocity = 0;
}