# AIAssignment

* Press `1` to switch to the basic motion mode.
* Press `2` to switch to the seeking mode.
* Press `3` to switch to the wandering mode.
* Press `4` to switch to the flocking mode.
* Press `5` to use kinematic steering.
* Press `6` to use dynamic steering. 
* Press `7` to use switch leader. 

I have four game modes in `ofApp::Updating()`. 
There are four cases responding to requirements.
You can see my comments on it.

My write-up:
http://zhitao.info/2019/01/30/ai-write-up-01/