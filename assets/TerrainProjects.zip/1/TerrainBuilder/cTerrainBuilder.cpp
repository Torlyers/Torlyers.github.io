﻿#include "cTerrainBuilder.h"
#include <Engine/Results/cResult.h>
#include <Engine/Platform/Platform.h>
#include <Tools/AssetBuildLibrary/Functions.h>
#include <External/Lua/Includes.h>
#include <iostream>
#include <fstream>
#include <Engine/Graphics/cRenderState.h>
#include <Engine/UserSettings/UserSettings.h>

#include <windows.h> 
#include <stdio.h> 

eae6320::cResult eae6320::Assets::cTerrainBuilder::Build(const std::vector<std::string>& i_arguments)
{
	auto result = Results::Success;

	{
		std::string* o_errorMessage = new std::string();
		if (!(result = ReadRawFileWriteMeshFile(m_path_source, m_path_target, o_errorMessage)))
		{
			eae6320::Assets::OutputErrorMessageWithFileInfo(m_path_source, o_errorMessage->c_str());
		}
	}

	return result;
}

eae6320::cResult eae6320::Assets::cTerrainBuilder::ReadRawFileWriteMeshFile(std::string i_sourcePath, std::string i_targetPath, std::string *& o_errorMessage)
{
	auto result = eae6320::Results::Success;

	eae6320::Platform::sDataFromFile dataFromFile;
	if (!(result = eae6320::Platform::LoadBinaryFile(i_sourcePath.c_str(), dataFromFile, o_errorMessage)))
	{
		result = Results::FileDoesntExist;
	}
	BYTE* data = reinterpret_cast<BYTE*>(dataFromFile.data);

	//create buffer
	uint32_t vertexCount = MAP_SIZE * MAP_SIZE;
	bool is32BitMesh = false;
	if (vertexCount > UINT16_MAX)
		is32BitMesh = true;
	Vertex* vertexBuffer = new Vertex[vertexCount]();
	uint32_t indexCount = (MAP_SIZE - 1) * (MAP_SIZE - 1) * 2 * 3;
	uint16_t* indexBuffer = nullptr;
	uint32_t* indexBuffer32 = nullptr;
	if (!is32BitMesh)
	{
		indexBuffer = new uint16_t[indexCount]();
	}
	else
	{
		indexBuffer32 = new uint32_t[indexCount]();
	}

	//make a mesh according to height map data
	size_t index = 0;
	for (int y = 0; y < MAP_SIZE; ++y)//row
	{
		for (int x = 0; x < MAP_SIZE; ++x)//column
		{
			//calculate vertex
			Vertex v;
			v.position[0] = x * VERTEX_SCALE;//x
			v.position[2] = y * VERTEX_SCALE;//z
			uint8_t height = data[y * MAP_SIZE + x];
			v.position[1] = height / 255.0f * HEIGHT_SCALE;//y			

			//calculate vertex color
			for (int i = 0; i < LEVEL_COUNT; ++i)
			{
				if (height > terrainLevels[i])
				{
					for (int j = 0; j < 4; ++j)
					{
						v.color[j] = levelColors[i][j];
					}
				}
				else
				{
					break;
				}
			}

			vertexBuffer[y * MAP_SIZE + x] = v;

			//calculate indice counter-clockwisely
			if (y == MAP_SIZE - 1)
				continue;

			if (x % MAP_SIZE != MAP_SIZE - 1)
			{
				if (!is32BitMesh)
				{
					uint16_t v0 = y * MAP_SIZE + x;
					uint16_t v1 = v0 + MAP_SIZE;
					uint16_t v2 = v0 + 1;
					indexBuffer[index++] = v0;
					indexBuffer[index++] = v1;
					indexBuffer[index++] = v2;
				}
				else
				{
					uint32_t v0 = y * MAP_SIZE + x;
					uint32_t v1 = v0 + MAP_SIZE;
					uint32_t v2 = v0 + 1;
					indexBuffer32[index++] = v0;
					indexBuffer32[index++] = v1;
					indexBuffer32[index++] = v2;
				}
				
			}

			if (x % MAP_SIZE != 0)
			{
				if (!is32BitMesh)
				{
					uint16_t v0 = y * MAP_SIZE + x;
					uint16_t v1 = v0 + MAP_SIZE - 1;
					uint16_t v2 = v1 + 1;
					indexBuffer[index++] = v0;
					indexBuffer[index++] = v1;
					indexBuffer[index++] = v2;
				}
				else
				{
					uint32_t v0 = y * MAP_SIZE + x;
					uint32_t v1 = v0 + MAP_SIZE - 1;
					uint32_t v2 = v1 + 1;
					indexBuffer32[index++] = v0;
					indexBuffer32[index++] = v1;
					indexBuffer32[index++] = v2;
				}
			}
		}
	}

	//write data into a binary file
	{
		std::ofstream binaryFile;
		binaryFile.open(i_targetPath.c_str(), std::ofstream::binary);

		binaryFile.write((char*)&vertexCount, sizeof(uint32_t));
		binaryFile.write((char*)&indexCount, sizeof(uint32_t));
		binaryFile.write(reinterpret_cast<char*>(vertexBuffer), sizeof(Vertex) * vertexCount);
		if (!is32BitMesh)
		{
			binaryFile.write(reinterpret_cast<char*>(indexBuffer), sizeof(uint16_t) * indexCount);
		}
		else
		{
			binaryFile.write(reinterpret_cast<char*>(indexBuffer32), sizeof(uint32_t) * indexCount);
		}
		binaryFile.close();
	}

	return result;
}