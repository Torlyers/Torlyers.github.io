﻿#pragma once

#include <Tools/AssetBuildLibrary/cbBuilder.h>
#include <Tools/HeightMapGenerator/HeightMapDefines.h>

namespace eae6320
{
	namespace Assets
	{
		struct Vertex
		{
			float   position[3] = { 0, 0, 0 };//x, y, z
			uint8_t color[4] = { 255, 255, 255, 255 };//r, g, b, a
		};

		class cTerrainBuilder: public cbBuilder
		{
		public:

			virtual cResult Build(const std::vector<std::string>& i_arguments) override;

		private:

			cResult ReadRawFileWriteMeshFile(std::string i_sourcePath, std::string i_targetPath, std::string*& o_errorMessage);
		};
	}
}
