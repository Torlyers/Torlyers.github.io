﻿#include "HeightMap.h"
#include "PerlinNoise.h"
#include "HeightMapDefines.h"
#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>

void eae6320::HeightMap::GenerateHeightMap(std::string i_fileName)
{
	std::vector<double> heights;
	std::vector<uint8_t> mappingHeights;
	PerlinNoise noise(0.1, 0.1, 200.0, 4, rand());

	for (int i = 0; i < MAP_SIZE; ++i)
	{
		for (int j = 0; j < MAP_SIZE; ++j)
		{
			auto height = noise.GetHeight((float)j, (float)i);
			heights.push_back(height);
		}
	}

	//LinearMapping
	auto maxItor = std::max_element(std::begin(heights), std::end(heights));
	auto minItor = std::min_element(std::begin(heights), std::end(heights));

	for (auto h : heights)
	{
		uint8_t inth = (uint8_t)(256 * (h - *minItor) / (*maxItor - *minItor));
		mappingHeights.push_back(inth);
	}

	//write data into a binary file
	{
		std::ofstream binaryFile;
		binaryFile.open(OUTPUT_PATH + i_fileName + ".raw", std::ofstream::binary);		
		binaryFile.write((char*)&mappingHeights[0], mappingHeights.size());
		binaryFile.close();
	}

}


