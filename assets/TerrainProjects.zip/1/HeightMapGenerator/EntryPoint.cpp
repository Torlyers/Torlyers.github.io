﻿#include "HeightMap.h"

int main(int argc, char* argv[])
{
	if (argc != 2)
		return -1;

	eae6320::HeightMap::GenerateHeightMap(argv[1]);

	return 0;
}