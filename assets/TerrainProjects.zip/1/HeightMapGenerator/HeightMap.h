﻿#pragma once



#include <string>

namespace eae6320
{
	namespace HeightMap
	{
		void GenerateHeightMap(std::string i_fileName);

	}
}