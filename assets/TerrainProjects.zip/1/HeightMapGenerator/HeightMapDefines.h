﻿#pragma once
#include<vector>

#define MAP_SIZE 500
#define STEP_SIZE 1 
#define VERTEX_SCALE 0.05f
#define HEIGHT_SCALE 5.0f

//height is from 0 to 255
const uint8_t LEVEL_COUNT = 4;

const uint8_t SEA_LEVEL = 10;
const uint8_t LAND_LEVEL = 80;
const uint8_t FOREST_LEVEL = 120;
const uint8_t SNOW_LEVEL = 180;

const uint8_t terrainLevels[LEVEL_COUNT] = { SEA_LEVEL, LAND_LEVEL, FOREST_LEVEL, SNOW_LEVEL };

//colors
const uint8_t SEA_COLOR[4] = { 71, 163, 201, 255 };
const uint8_t LAND_COLOR[4] = { 118, 95, 62, 255 };
const uint8_t FOREST_COLOR[4] = { 132, 196, 85, 255 };
const uint8_t SNOW_COLOR[4] = { 255, 255, 255, 255 };

const uint8_t levelColors[LEVEL_COUNT][4] = {SEA_COLOR[0], SEA_COLOR[1], SEA_COLOR[2], SEA_COLOR[3],
											 LAND_COLOR[0], LAND_COLOR[1], LAND_COLOR[2], LAND_COLOR[3],
											 FOREST_COLOR[0], FOREST_COLOR[1], FOREST_COLOR[2], FOREST_COLOR[3],
											 SNOW_COLOR[0], SNOW_COLOR[1], SNOW_COLOR[2], SNOW_COLOR[3],};

//output path
const std::string OUTPUT_PATH = "../../../../MyGame_/Content/HeightMaps/";