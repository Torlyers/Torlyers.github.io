﻿#pragma once
#include <Engine/Results/Results.h>
#include <string>
#include <vector>
#include <Engine/Graphics/cMesh.h>
#include <Engine/Graphics/cEffect.h>
#include <Engine/Math/cQuaternion.h>
#include <Engine/Math/sVector.h>
#include <Engine/Math/cMatrix_transformation.h>
#include <Engine/Physics/sRigidBodyState.h>
#include <Tools/HeightMapGenerator/HeightMapDefines.h>

namespace eae6320
{
	namespace Terrain
	{
		class cTerrain
		{
		public:

			static void CreateTerrain(std::string i_filePath, cTerrain*& o_terrain);

			void Draw(const float i_elapsedSecondCount_sinceLastSimulationUpdate);
			Physics::sRigidBodyState& GetRigidBody() { return m_rigidBody; }

			cResult CleanUp();

		private:
			cTerrain() { m_pMesh = nullptr; m_pEffect = nullptr; }
			~cTerrain() {}
		
			Physics::sRigidBodyState m_rigidBody;
			Math::cMatrix_transformation m_matrix;
			eae6320::Graphics::Mesh* m_pMesh;
			eae6320::Graphics::Effect* m_pEffect;
			float m_scale;
		};
	}
}