﻿#include "cTerrain.h"
#include <Engine/Platform/Platform.h>
#include <Engine/Graphics/Graphics.h>



void eae6320::Terrain::cTerrain::CreateTerrain(std::string i_filePath, cTerrain *& o_terrain)
{
	cTerrain* terrain = new cTerrain();
	eae6320::Graphics::Mesh::Load(i_filePath, terrain->m_pMesh);
	eae6320::Graphics::Effect::Load("data/effects/terrain.eft", terrain->m_pEffect);
	o_terrain = terrain;
}


void eae6320::Terrain::cTerrain::Draw(const float i_elapsedSecondCount_sinceLastSimulationUpdate)
{
	auto pos = m_rigidBody.PredictFuturePosition(i_elapsedSecondCount_sinceLastSimulationUpdate);
	auto ori = m_rigidBody.PredictFutureOrientation(i_elapsedSecondCount_sinceLastSimulationUpdate);
	auto matrix = eae6320::Math::cMatrix_transformation(ori, pos);
	eae6320::Graphics::SubmitMeshAndEffect(m_pMesh, m_pEffect, matrix);
}

eae6320::cResult eae6320::Terrain::cTerrain::CleanUp()
{
	auto result = Results::Success;

	m_pEffect->DecrementReferenceCount();
	m_pEffect = nullptr;

	m_pMesh->DecrementReferenceCount();
	m_pMesh = nullptr;

	return result;
}
